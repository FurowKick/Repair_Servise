﻿using System;
using System.Data;
using System.Windows.Forms;
using RepairServise.Data;
using RepairServise.Helpers;

namespace RepairServise.Forms
{
    public partial class StatisticsForm : Form
    {
        public StatisticsForm()
        {
            InitializeComponent();
        }

        private void StatisticsForm_Load(object sender, EventArgs e)
        {
            LoadStatistics();
        }

        private void LoadStatistics()
        {
            try
            {
                // Создаём таблицу для результатов
                DataTable resultTable = new DataTable();
                resultTable.Columns.Add("Категория", typeof(string));
                resultTable.Columns.Add("Показатель", typeof(string));
                resultTable.Columns.Add("Значение", typeof(string));

                // 1. Общая статистика
                var totalQuery = DatabaseHelper.ExecuteQuery("SELECT COUNT(*) FROM requests");
                int total = Convert.ToInt32(totalQuery.Rows[0][0]);
                resultTable.Rows.Add("📊 ОБЩАЯ СТАТИСТИКА", "", "");
                resultTable.Rows.Add("Общее количество заявок", "", total.ToString());

                // 2. Выполненные заявки
                var completedQuery = DatabaseHelper.ExecuteQuery(@"
            SELECT COUNT(*) 
            FROM requests r 
            JOIN statuses s ON r.status_id = s.status_id 
            WHERE s.status_name = 'Готова к выдаче'");
                int completed = Convert.ToInt32(completedQuery.Rows[0][0]);
                resultTable.Rows.Add("✅ Выполненные заявки", "(статус: Готова к выдаче)", completed.ToString());

                // 3. В процессе
                var inProgressQuery = DatabaseHelper.ExecuteQuery(@"
            SELECT COUNT(*) 
            FROM requests r 
            JOIN statuses s ON r.status_id = s.status_id 
            WHERE s.status_name = 'В процессе ремонта'");
                int inProgress = Convert.ToInt32(inProgressQuery.Rows[0][0]);
                resultTable.Rows.Add("⏳ В процессе ремонта", "", inProgress.ToString());

                // 4. Новые заявки
                var newQuery = DatabaseHelper.ExecuteQuery(@"
            SELECT COUNT(*) 
            FROM requests r 
            JOIN statuses s ON r.status_id = s.status_id 
            WHERE s.status_name = 'Новая заявка'");
                int newRequests = Convert.ToInt32(newQuery.Rows[0][0]);
                resultTable.Rows.Add("📝 Новые заявки", "", newRequests.ToString());

                // Пустая строка
                resultTable.Rows.Add("", "", "");

                // 5. Среднее время выполнения
                resultTable.Rows.Add("⏱️ СРЕДНЕЕ ВРЕМЯ ВЫПОЛНЕНИЯ", "", "");

                var avgTimeQuery = DatabaseHelper.ExecuteQuery(@"
    SELECT 
        ROUND(AVG(
            EXTRACT(EPOCH FROM (
                GREATEST(completion_date::timestamp, created_date::timestamp) - 
                LEAST(completion_date::timestamp, created_date::timestamp)
            )) / 86400
        ), 2)
    FROM requests 
    WHERE status_id = 4 AND completion_date IS NOT NULL 
    AND completion_date != created_date");

                string avgTime = avgTimeQuery.Rows[0][0] != DBNull.Value
                    ? avgTimeQuery.Rows[0][0].ToString()
                    : "Нет данных";
                resultTable.Rows.Add("Среднее время ремонта", "(в днях)", avgTime);

                // 6. Минимальное время
                var minTimeQuery = DatabaseHelper.ExecuteQuery(@"
    SELECT 
        ROUND(MIN(
            EXTRACT(EPOCH FROM (
                GREATEST(completion_date::timestamp, created_date::timestamp) - 
                LEAST(completion_date::timestamp, created_date::timestamp)
            )) / 86400
        ), 2)
    FROM requests 
    WHERE status_id = 4 AND completion_date IS NOT NULL 
    AND completion_date != created_date");

                string minTime = minTimeQuery.Rows[0][0] != DBNull.Value
                    ? minTimeQuery.Rows[0][0].ToString()
                    : "Нет данных";
                resultTable.Rows.Add("Минимальное время", "(в днях)", minTime);

                // 7. Максимальное время
                var maxTimeQuery = DatabaseHelper.ExecuteQuery(@"
    SELECT 
        ROUND(MAX(
            EXTRACT(EPOCH FROM (
                GREATEST(completion_date::timestamp, created_date::timestamp) - 
                LEAST(completion_date::timestamp, created_date::timestamp)
            )) / 86400
        ), 2)
    FROM requests 
    WHERE status_id = 4 AND completion_date IS NOT NULL 
    AND completion_date != created_date");

                string maxTime = maxTimeQuery.Rows[0][0] != DBNull.Value
                    ? maxTimeQuery.Rows[0][0].ToString()
                    : "Нет данных";
                resultTable.Rows.Add("Максимальное время", "(в днях)", maxTime);

                // Пустая строка
                resultTable.Rows.Add("", "", "");

                // 8. Статистика по технике
                resultTable.Rows.Add("🔧 СТАТИСТИКА ПО ТЕХНИКЕ", "", "");

                var techQuery = DatabaseHelper.ExecuteQuery(@"
            SELECT equipment_type, COUNT(*) as count
            FROM requests 
            GROUP BY equipment_type 
            ORDER BY count DESC");

                foreach (DataRow row in techQuery.Rows)
                {
                    resultTable.Rows.Add(row["equipment_type"].ToString(), "Количество заявок", row["count"].ToString());
                }

                // Отображаем данные
                dgvStats.DataSource = resultTable;

                // Настройка отображения
                if (dgvStats.Columns.Contains("Категория"))
                    dgvStats.Columns["Категория"].Width = 250;
                if (dgvStats.Columns.Contains("Показатель"))
                    dgvStats.Columns["Показатель"].Width = 250;
                if (dgvStats.Columns.Contains("Значение"))
                    dgvStats.Columns["Значение"].Width = 200;

                lblInfo.Text = $"Всего строк: {resultTable.Rows.Count} | Обновлено: {DateTime.Now:dd.MM.yyyy HH:mm}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки статистики:\n{ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadStatistics();
            MessageBox.Show("Статистика обновлена", "Информация",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}