﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepairServise.Models
{
    public class Comment
    {
        public int CommentId { get; set; }
        public string Message { get; set; } = string.Empty;
        public int MasterId { get; set; }
        public string? MasterName { get; set; }
        public int RequestId { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
