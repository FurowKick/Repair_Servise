﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace RepairServise.Helpers
{
    public static class ValidationHelper
    {
        public static bool IsPhoneValid(string phone) =>
            Regex.IsMatch(phone, @"^(\+7|8)?[\s\-]?\(?[489][0-9]{2}\)?[\s\-]?[0-9]{3}[\s\-]?[0-9]{2}[\s\-]?[0-9]{2}$");

        public static bool IsNotEmpty(string value, out string errorMessage)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                errorMessage = "Поле не может быть пустым";
                return false;
            }
            errorMessage = string.Empty;
            return true;
        }

        public static bool ValidateRequestFields(string clientName, string clientPhone, string equipmentType, string model, string problemDesc, out string error)
        {
            if (!IsNotEmpty(clientName, out error)) return false;
            if (!IsNotEmpty(clientPhone, out error)) return false;
            if (!IsPhoneValid(clientPhone)) { error = "Некорректный формат телефона"; return false; }
            if (!IsNotEmpty(equipmentType, out error)) return false;
            if (!IsNotEmpty(model, out error)) return false;
            if (!IsNotEmpty(problemDesc, out error)) return false;

            error = string.Empty;
            return true;
        }
    }
}
