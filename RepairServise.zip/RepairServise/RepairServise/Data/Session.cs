﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepairServise.Helpers
{
    public static class Session
    {
        public static int UserId { get; set; }
        public static string UserName { get; set; } = string.Empty;
        public static string RoleName { get; set; } = string.Empty;

        public static bool IsManager => RoleName == "Менеджер";
        public static bool IsMaster => RoleName == "Мастер";
        public static bool IsOperator => RoleName == "Оператор";
        public static bool IsClient => RoleName == "Заказчик";

        public static void Clear()
        {
            UserId = 0;
            UserName = string.Empty;
            RoleName = string.Empty;
        }
    }
}
