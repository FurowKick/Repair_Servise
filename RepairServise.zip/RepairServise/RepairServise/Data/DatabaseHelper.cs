﻿using Npgsql;
using System.Data;
using System;

namespace RepairServise.Data
{
    public static class DatabaseHelper
    {
        public static string ConnectionString =>
            "Host=localhost;Port=5432;Database=repait_db;Username=postgres;Password=;";

        public static NpgsqlConnection GetConnection() =>
            new NpgsqlConnection(ConnectionString);

        public static bool TestConnection()
        {
            try
            {
                using var conn = GetConnection();
                conn.Open();
                return conn.State == ConnectionState.Open;
            }
            catch
            {
                return false;
            }
        }

        // Выполняет SELECT запрос и возвращает DataTable
        public static DataTable ExecuteQuery(string query, NpgsqlParameter[] parameters = null)
        {
            var table = new DataTable();
            try
            {
                using var conn = GetConnection();
                using var cmd = new NpgsqlCommand(query, conn);
                if (parameters != null) cmd.Parameters.AddRange(parameters);

                conn.Open();

                using var adapter = new NpgsqlDataAdapter(cmd);
                adapter.Fill(table);
            }
            catch (NpgsqlException ex)
            {
                throw new InvalidOperationException($"Ошибка БД: {ex.Message}", ex);
            }
            return table;
        }

        // Выполняет INSERT/UPDATE/DELETE запрос
        public static int ExecuteNonQuery(string query, NpgsqlParameter[] parameters = null)
        {
            try
            {
                using var conn = GetConnection();
                using var cmd = new NpgsqlCommand(query, conn);
                if (parameters != null) cmd.Parameters.AddRange(parameters);

                conn.Open();
                return cmd.ExecuteNonQuery();
            }
            catch (NpgsqlException ex)
            {
                throw new InvalidOperationException($"Ошибка БД: {ex.Message}", ex);
            }
        }
    }
}