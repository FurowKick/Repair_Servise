﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using RepairServise.Data;
using RepairServise.Helpers;

namespace RepairServise.Forms
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            txtLogin.Focus();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                ShowError("Введите логин и пароль");
                return;
            }

            try
            {
                using var conn = DatabaseHelper.GetConnection();
                conn.Open();

                var cmd = new NpgsqlCommand(
                    "SELECT u.user_id, u.full_name, r.role_name " +
                    "FROM users u JOIN roles r ON u.role_id = r.role_id " +
                    "WHERE u.login = @login AND u.password_hash = @password",
                    conn);

                cmd.Parameters.AddWithValue("@login", login);
                cmd.Parameters.AddWithValue("@password", password);

                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    Session.UserId = reader.GetInt32(0);
                    Session.UserName = reader.GetString(1);
                    Session.RoleName = reader.GetString(2);

                    this.Hide();
                    new MainForm().ShowDialog();
                    Application.Exit();
                }
                else
                {
                    ShowError("Неверный логин или пароль");
                }
            }
            catch (NpgsqlException ex)
            {
                ShowError($"Ошибка подключения к БД:\n{ex.Message}");
            }
            catch (Exception ex)
            {
                ShowError($"Непредвиденная ошибка:\n{ex.Message}");
            }
        }

        private void ShowError(string message)
        {
            lblError.Text = message;
            lblError.Visible = true;
            MessageBox.Show(message, "Ошибка входа",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void txtLogin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter) btnLogin.PerformClick();
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter) btnLogin.PerformClick();
        }
    }
}
