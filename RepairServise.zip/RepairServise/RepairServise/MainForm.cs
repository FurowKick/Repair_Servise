﻿using System;
using System.Windows.Forms;
using RepairServise.Helpers;

namespace RepairServise.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            SetupMenuByRole();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.Text = $"БытСервис | {Session.UserName} ({Session.RoleName})";
        }

        private void SetupMenuByRole()
        {
            mnuRequests.Visible = false;
            mnuStatistics.Visible = false;
            mnuProfile.Visible = false;
            mnuExit.Visible = true;

            if (Session.IsManager || Session.IsOperator)
            {
                mnuRequests.Visible = true;
                mnuStatistics.Visible = true;
                mnuProfile.Visible = true;
            }
            else if (Session.IsMaster)
            {
                mnuRequests.Visible = true;
                mnuStatistics.Visible = false;
                mnuProfile.Visible = true;
            }
            else if (Session.IsClient)
            {
                mnuRequests.Visible = true;
                mnuStatistics.Visible = false;
                mnuProfile.Visible = true;
            }
        }

        private void mnuRequests_Click(object sender, EventArgs e)
        {
            RequestsForm frm = new RequestsForm();
            frm.ShowDialog();
        }

        private void mnuStatistics_Click(object sender, EventArgs e)
        {
            // Статистика доступна только менеджерам и операторам
            if (Session.IsManager || Session.IsOperator)
            {
                StatisticsForm frm = new StatisticsForm();
                frm.ShowDialog();
            }
            else
            {
                MessageBox.Show("У вас нет доступа к статистике", "Доступ запрещён",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void mnuProfile_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"Пользователь: {Session.UserName}\nРоль: {Session.RoleName}",
                "Профиль", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            var res = MessageBox.Show("Вы действительно хотите выйти?", "Выход",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (res == DialogResult.Yes)
            {
                Session.Clear();
                this.Close();
            }
        }
    }
}