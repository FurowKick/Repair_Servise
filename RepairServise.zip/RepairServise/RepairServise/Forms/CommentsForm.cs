﻿using System;
using System.Data;
using System.Windows.Forms;
using RepairServise.Data;
using Npgsql;

namespace RepairServise.Forms
{
    public partial class CommentsForm : Form
    {
        public int RequestId { get; set; }
        private DataTable commentsTable;

        public CommentsForm()
        {
            InitializeComponent();
            this.Load += CommentsForm_Load;
        }

        private void CommentsForm_Load(object sender, EventArgs e)
        {
            this.Text = $"Комментарии к заявке #{RequestId}";
            LoadComments();
        }

        private void LoadComments()
        {
            string query = @"
                SELECT 
                    c.comment_id AS ""ID"",
                    c.message AS ""Комментарий"",
                    u.full_name AS ""Мастер"",
                    c.created_at AS ""Дата""
                FROM comments c
                JOIN users u ON c.master_id = u.user_id
                WHERE c.request_id = @requestId
                ORDER BY c.created_at DESC";

            var parameters = new[] { new NpgsqlParameter("@requestId", RequestId) };
            commentsTable = DatabaseHelper.ExecuteQuery(query, parameters);
            dgvComments.DataSource = commentsTable;

            // Настройка колонок
            if (dgvComments.Columns.Contains("ID")) dgvComments.Columns["ID"].Width = 50;
            if (dgvComments.Columns.Contains("Комментарий")) dgvComments.Columns["Комментарий"].Width = 300;
            if (dgvComments.Columns.Contains("Мастер")) dgvComments.Columns["Мастер"].Width = 150;
            if (dgvComments.Columns.Contains("Дата")) dgvComments.Columns["Дата"].Width = 120;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Открываем форму добавления комментария
            var addForm = new CommentAddForm();
            addForm.RequestId = RequestId;

            if (addForm.ShowDialog() == DialogResult.OK)
            {
                LoadComments();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvComments.CurrentRow == null)
            {
                MessageBox.Show("Выберите комментарий для удаления", "Предупреждение",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var result = MessageBox.Show("Удалить выбранный комментарий?", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    int commentId = Convert.ToInt32(dgvComments.CurrentRow.Cells["ID"].Value);
                    string query = "DELETE FROM comments WHERE comment_id = @id";
                    var parameters = new[] { new NpgsqlParameter("@id", commentId) };

                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                    MessageBox.Show("Комментарий удалён", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadComments();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}