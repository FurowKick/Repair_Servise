﻿using System;
using System.Data;
using System.Windows.Forms;
using RepairServise.Data;
using RepairServise.Helpers;
using Npgsql;

namespace RepairServise.Forms
{
    public partial class RequestsForm : Form
    {
        private DataTable requestsTable;
        private DataTable originalTable; // Для хранения всех данных

        public RequestsForm()
        {
            InitializeComponent();
            LoadRequests();
            SetupButtonsByRole();
        }

        private void SetupButtonsByRole()
        {
            // Разграничение прав на кнопки (ТЗ п. 3.2)
            bool canEdit = Session.IsManager || Session.IsOperator || Session.IsMaster;
            bool canDelete = Session.IsManager || Session.IsOperator;
            bool canAdd = Session.IsManager || Session.IsOperator;

            btnAdd.Visible = canAdd;
            btnEdit.Visible = canEdit;
            btnDelete.Visible = canDelete;
        }

        private void LoadRequests()
        {
            try
            {
                string query = @"
            SELECT 
                r.request_id AS ID,
                r.created_date AS ""Дата создания"",
                r.equipment_type AS ""Тип техники"",
                r.model AS ""Модель"",
                LEFT(r.problem_description, 50) AS ""Проблема"",
                c.full_name AS ""Клиент"",
                c.phone AS ""Телефон"",
                s.status_name AS ""Статус"",
                m.full_name AS ""Мастер"",
                r.completion_date AS ""Дата завершения""
            FROM requests r
            JOIN users c ON r.client_id = c.user_id
            JOIN statuses s ON r.status_id = s.status_id
            LEFT JOIN users m ON r.assigned_master_id = m.user_id";

                if (Session.IsClient)
                {
                    query += " WHERE r.client_id = @userId";
                }
                else if (Session.IsMaster)
                {
                    query += " WHERE r.assigned_master_id = @userId OR r.assigned_master_id IS NULL";
                }

                query += " ORDER BY r.created_date DESC";

                NpgsqlParameter[] parameters = null;
                if (Session.IsClient || Session.IsMaster)
                {
                    parameters = new[] { new NpgsqlParameter("@userId", Session.UserId) };
                }

                requestsTable = DatabaseHelper.ExecuteQuery(query, parameters);
                originalTable = requestsTable.Copy();

                dgvRequests.DataSource = requestsTable;

                // Безопасная настройка ширины колонок
                SetColumnWidth("ID", 50);
                SetColumnWidth("Дата создания", 100);
                SetColumnWidth("Тип техники", 100);
                SetColumnWidth("Модель", 120);
                SetColumnWidth("Проблема", 150);
                SetColumnWidth("Клиент", 130);
                SetColumnWidth("Телефон", 100);
                SetColumnWidth("Статус", 120);
                SetColumnWidth("Мастер", 130);
                SetColumnWidth("Дата завершения", 100);

                // Автоматическое растягивание остальных колонок
                dgvRequests.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Не удалось загрузить заявки:\n{ex.Message}",
                    "Ошибка загрузки данных",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        // Вспомогательный метод для безопасной установки ширины колонки
        private void SetColumnWidth(string columnName, int width)
        {
            if (dgvRequests.Columns.Contains(columnName))
            {
                dgvRequests.Columns[columnName].Width = width;
                dgvRequests.Columns[columnName].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            }
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Открываем форму в режиме добавления
            RequestEditorForm editor = new RequestEditorForm();
            editor.RequestId = 0; // 0 означает новая заявка

            // Если форма закрылась с OK (успешно сохранено) — обновляем список
            if (editor.ShowDialog() == DialogResult.OK)
            {
                LoadRequests();
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvRequests.CurrentRow == null)
            {
                MessageBox.Show("Выберите заявку для редактирования", "Предупреждение",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Получаем ID выбранной строки
            // Важно: Имя столбца должно совпадать с тем, что в SQL запросе (ID)
            int selectedId = Convert.ToInt32(dgvRequests.CurrentRow.Cells["ID"].Value);

            RequestEditorForm editor = new RequestEditorForm();
            editor.RequestId = selectedId;

            // Если форма закрылась с OK — обновляем список
            if (editor.ShowDialog() == DialogResult.OK)
            {
                LoadRequests();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvRequests.CurrentRow == null)
            {
                MessageBox.Show("Выберите заявку для удаления", "Предупреждение",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Подтверждение удаления (ТЗ п. 3.4 - обработка исключений)
            var result = MessageBox.Show(
                "Вы действительно хотите удалить выбранную заявку?\nЭто действие нельзя отменить.",
                "Подтверждение удаления",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result == DialogResult.Yes)
            {
                try
                {
                    int requestId = Convert.ToInt32(dgvRequests.CurrentRow.Cells["ID"].Value);
                    string query = "DELETE FROM requests WHERE request_id = @id";
                    var parameters = new[] { new NpgsqlParameter("@id", requestId) };

                    DatabaseHelper.ExecuteNonQuery(query, parameters);

                    MessageBox.Show("Заявка успешно удалена", "Удаление",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    LoadRequests(); // Перезагружаем данные
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        $"Не удалось удалить заявку:\n{ex.Message}",
                        "Ошибка удаления",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            LoadRequests();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(searchText))
            {
                requestsTable = originalTable.Copy();
                dgvRequests.DataSource = requestsTable;
                return;
            }

            // Поиск по ID, клиенту, типу техники, модели
            var filteredTable = originalTable.Clone();

            foreach (DataRow row in originalTable.Rows)
            {
                if (row["ID"].ToString().Contains(searchText) ||
                    row["Клиент"].ToString().ToLower().Contains(searchText) ||
                    row["Тип техники"].ToString().ToLower().Contains(searchText) ||
                    row["Модель"].ToString().ToLower().Contains(searchText))
                {
                    filteredTable.ImportRow(row);
                }
            }

            if (filteredTable.Rows.Count == 0)
            {
                MessageBox.Show("Заявки не найдены. Измените параметры поиска.",
                    "Результат поиска",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }

            requestsTable = filteredTable;
            dgvRequests.DataSource = requestsTable;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                btnSearch.PerformClick();
            }
        }

        private void dgvRequests_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                btnEdit.PerformClick();
            }
        }
    }
}