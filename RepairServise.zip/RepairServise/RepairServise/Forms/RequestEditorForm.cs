﻿using System;
using System.Data;
using System.Windows.Forms;
using RepairServise.Data;
using RepairServise.Helpers;
using Npgsql;

namespace RepairServise.Forms
{
    public partial class RequestEditorForm : Form
    {
        public int RequestId { get; set; } = 0;
        private bool IsNewRequest => RequestId == 0;

        public RequestEditorForm()
        {
            InitializeComponent();
        }

        private void RequestEditorForm_Load(object sender, EventArgs e)
        {
            this.Text = IsNewRequest ? "Добавление заявки" : $"Редактирование заявки #{RequestId}";
            lblHeader.Text = this.Text;

            LoadComboBoxes();

            if (!IsNewRequest)
            {
                LoadRequestData();
            }
            else
            {
                dtpDate.Value = DateTime.Now;
            }
        }

        private void LoadComboBoxes()
        {
            try
            {
                // Клиенты (role_id = 4)
                var clients = DatabaseHelper.ExecuteQuery(
                    "SELECT user_id, full_name FROM users WHERE role_id = 4 ORDER BY full_name");
                cmbClient.DataSource = clients;
                cmbClient.DisplayMember = "full_name";
                cmbClient.ValueMember = "user_id";

                // Мастера (role_id = 2)
                var masters = DatabaseHelper.ExecuteQuery(
                    "SELECT user_id, full_name FROM users WHERE role_id = 2 ORDER BY full_name");
                cmbMaster.DataSource = masters;
                cmbMaster.DisplayMember = "full_name";
                cmbMaster.ValueMember = "user_id";
                cmbMaster.SelectedIndex = -1;

                // Статусы
                var statuses = DatabaseHelper.ExecuteQuery(
                    "SELECT status_id, status_name FROM statuses ORDER BY status_id");
                cmbStatus.DataSource = statuses;
                cmbStatus.DisplayMember = "status_name";
                cmbStatus.ValueMember = "status_id";

                // Типы техники
                string[] types = {
                    "Холодильник",
                    "Стиральная машина",
                    "Фен",
                    "Тостер",
                    "Мультиварка",
                    "Плита",
                    "Посудомоечная машина",
                    "Другое"
                };
                cmbType.DataSource = types;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки справочников:\n{ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadRequestData()
        {
            try
            {
                string query = "SELECT * FROM requests WHERE request_id = @id";
                var parameters = new[] { new NpgsqlParameter("@id", RequestId) };

                var table = DatabaseHelper.ExecuteQuery(query, parameters);

                if (table.Rows.Count > 0)
                {
                    var row = table.Rows[0];

                    cmbClient.SelectedValue = row["client_id"];
                    cmbType.Text = row["equipment_type"].ToString();
                    txtModel.Text = row["model"].ToString();
                    txtProblem.Text = row["problem_description"].ToString();
                    cmbStatus.SelectedValue = row["status_id"];

                    if (row["created_date"] != DBNull.Value)
                    {
                        string dateStr = row["created_date"].ToString();
                        if (DateTime.TryParse(dateStr, out DateTime parsedDate))
                        {
                            dtpDate.Value = parsedDate;
                        }
                        else
                        {
                            dtpDate.Value = DateTime.Now;
                        }
                    }
                    else
                    {
                        dtpDate.Value = DateTime.Now;
                    }

                    txtParts.Text = row["parts_info"].ToString();

                    if (row["assigned_master_id"] != DBNull.Value)
                    {
                        cmbMaster.SelectedValue = row["assigned_master_id"];
                    }
                    else
                    {
                        cmbMaster.SelectedIndex = -1;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных заявки:\n{ex.Message}",
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Валидация
            if (cmbClient.SelectedValue == null)
            {
                MessageBox.Show("Выберите клиента", "Ошибка ввода",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbClient.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtModel.Text))
            {
                MessageBox.Show("Укажите модель техники", "Ошибка ввода",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtModel.Focus();
                return;
            }

            if (cmbStatus.SelectedValue == null)
            {
                MessageBox.Show("Выберите статус заявки", "Ошибка ввода",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbStatus.Focus();
                return;
            }

            try
            {
                string query;
                if (IsNewRequest)
                {
                    query = @"INSERT INTO requests 
                              (created_date, equipment_type, model, problem_description, 
                               status_id, parts_info, assigned_master_id, client_id)
                              VALUES 
                              (@date, @type, @model, @desc, @status, @parts, @master, @client)";
                }
                else
                {
                    query = @"UPDATE requests SET
                              created_date = @date,
                              equipment_type = @type,
                              model = @model,
                              problem_description = @desc,
                              status_id = @status,
                              parts_info = @parts,
                              assigned_master_id = @master,
                              client_id = @client
                              WHERE request_id = @id";
                }

                var parameters = new NpgsqlParameter[]
                {
                    new NpgsqlParameter("@date", dtpDate.Value),
                    new NpgsqlParameter("@type", cmbType.Text),
                    new NpgsqlParameter("@model", txtModel.Text.Trim()),
                    new NpgsqlParameter("@desc", txtProblem.Text.Trim()),
                    new NpgsqlParameter("@status", cmbStatus.SelectedValue),
                    new NpgsqlParameter("@parts", txtParts.Text.Trim()),
                    new NpgsqlParameter("@master", (object)cmbMaster.SelectedValue ?? DBNull.Value),
                    new NpgsqlParameter("@client", cmbClient.SelectedValue)
                };

                if (!IsNewRequest)
                {
                    Array.Resize(ref parameters, parameters.Length + 1);
                    parameters[parameters.Length - 1] = new NpgsqlParameter("@id", RequestId);
                }

                DatabaseHelper.ExecuteNonQuery(query, parameters);

                MessageBox.Show("Заявка успешно сохранена!", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения заявки:\n{ex.Message}",
                    "Ошибка базы данных", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btnComments_Click(object sender, EventArgs e)
        {
            if (IsNewRequest)
            {
                MessageBox.Show("Сначала сохраните заявку, чтобы добавить комментарии",
                    "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var commentsForm = new CommentsForm();
            commentsForm.RequestId = RequestId;
            commentsForm.ShowDialog();
        }
    }
}