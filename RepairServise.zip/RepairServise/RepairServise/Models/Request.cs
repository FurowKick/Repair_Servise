﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepairServise.Models
{
    public class Request
    {
        public int RequestId { get; set; }
        public DateTime CreatedDate { get; set; }
        public string EquipmentType { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string ProblemDescription { get; set; } = string.Empty;
        public int StatusId { get; set; }
        public string? StatusName { get; set; }
        public DateTime? CompletionDate { get; set; }
        public string PartsInfo { get; set; } = string.Empty;
        public int? AssignedMasterId { get; set; }
        public string? MasterName { get; set; }
        public int ClientId { get; set; }
        public string? ClientName { get; set; }
    }
}
