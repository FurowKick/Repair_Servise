﻿using System;
using System.Windows.Forms;
using RepairServise.Data;
using RepairServise.Helpers;
using Npgsql;

namespace RepairServise.Forms
{
    public partial class CommentAddForm : Form
    {
        public int RequestId { get; set; }

        public CommentAddForm()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string message = txtMessage.Text.Trim();

            if (string.IsNullOrEmpty(message))
            {
                MessageBox.Show("Введите текст комментария", "Предупреждение",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query = @"INSERT INTO comments (message, master_id, request_id, created_at)
                                 VALUES (@message, @masterId, @requestId, NOW())";

                var parameters = new NpgsqlParameter[]
                {
                    new NpgsqlParameter("@message", message),
                    new NpgsqlParameter("@masterId", Session.UserId),
                    new NpgsqlParameter("@requestId", RequestId)
                };

                DatabaseHelper.ExecuteNonQuery(query, parameters);

                MessageBox.Show("Комментарий добавлен", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}