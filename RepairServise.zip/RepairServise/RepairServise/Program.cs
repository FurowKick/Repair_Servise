﻿using System;
using System.Windows.Forms;
using RepairServise.Forms;  // ← ДОБАВИТЬ ЭТУ СТРОКУ

namespace RepairServise
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new LoginForm());  // ← Запустить LoginForm вместо MainForm
        }
    }
}