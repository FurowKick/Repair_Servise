﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepairServise.Models
{
    public class Status
    {
        public int StatusId { get; set; }
        public string StatusName { get; set; } = string.Empty;
    }
}
